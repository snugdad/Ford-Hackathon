```
export FLASK_APP=HelloWorld.py
flask run
```
